#pragma once

#include <QVector>

#include "utils.h"

struct Pose {
  Pose() = default;

  static Pose fromFrame(const V6d& frame);
  static Pose fromTransform(const M4d& transform);
  static Pose fromAxes(const V3d& t, const V3d& b, const V3d& n, const V3d& p);

  V6d frame{V6d::Zero()};
  M4d transf{M4d::Identity()};

  V3d t{V3d::Zero()};
  V3d b{V3d::Zero()};
  V3d n{V3d::Zero()};
  V3d p{V3d::Zero()};

  V3d pos() const;
  M3d rot() const;

private:
  void syncTransfByAxes();
  void syncAxesByTransf();
  void syncFrameByTransf();
  void syncTransfByFrame();
};

QVector<V6d> posesToFrames(const QVector<Pose>& poses);
