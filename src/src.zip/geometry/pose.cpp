#include "pose.h"

Pose Pose::fromFrame(const V6d &frame_)
{
  Pose out;
  out.frame = frame_;
  out.syncTransfByFrame();
  out.syncAxesByTransf();
  return out;
}

Pose Pose::fromTransform(const M4d &T_)
{
  Pose out;
  out.transf = T_;
  out.syncAxesByTransf();
  out.syncFrameByTransf();
  return out;
}

Pose Pose::fromAxes(const V3d &t_, const V3d &b_, const V3d &n_, const V3d &p_)
{
  Pose out;
  out.t = t_;
  out.b = b_;
  out.n = n_;
  out.p = p_;
  out.syncTransfByAxes();
  out.syncFrameByTransf();
  return out;
}

void Pose::syncTransfByAxes()
{
  transf.setIdentity();
  transf.block<3,1>(0,0) = t;
  transf.block<3,1>(0,1) = b;
  transf.block<3,1>(0,2) = n;
  transf.block<3,1>(0,3) = p;
}

void Pose::syncAxesByTransf()
{
  p = transf.block<3,1>(0,3);
  const M3d R = transf.block<3,3>(0,0);
  t = R.col(0);
  b = R.col(1);
  n = R.col(2);

  const double eps = 1e-12;

  if (t.norm() > eps) t.normalize();
  if (b.norm() > eps) b.normalize();
  if (n.norm() > eps) n.normalize();
}

void Pose::syncFrameByTransf()
{
  const Eigen::Vector3d tr = transf.block<3,1>(0,3);
  const EulerSolution eul = rot2euler(transf.topLeftCorner<3,3>(), true);
  frame << tr.x(), tr.y(), tr.z(), eul.A1, eul.B1, eul.C1;
}

void Pose::syncTransfByFrame()
{
  const M3d R = euler2rot(frame(3), frame(4), frame(5), true);

  transf.setIdentity();
  transf.block<3,3>(0,0) = R;
  transf.block<3,1>(0,3) = V3d(frame(0), frame(1), frame(2));
}

QVector<V6d> posesToFrames(const QVector<Pose>& poses)
{
  QVector<V6d> frames;
  frames.reserve(poses.size());

  for (const Pose& p : poses)
    frames.push_back(p.frame);   // [x,y,z,A,B,C] in deg

  return frames;
}
