#pragma once

#include <Eigen/Core>

struct Plane
{
  static Plane fromPoints(const Eigen::Ref<const Eigen::VectorXd>& x,
                          const Eigen::Ref<const Eigen::VectorXd>& y,
                          const Eigen::Ref<const Eigen::VectorXd>& z);

  double A{};
  double B{};
  double C{};
  double D{};

  double AA{};
  double BB{};
  double DD{};
};