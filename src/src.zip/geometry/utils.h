#pragma once

#include <Eigen/Core>
#include <Eigen/Geometry>

using V6d = Eigen::Matrix<double, 6, 1>;
using V3d = Eigen::Vector3d;
using M3d = Eigen::Matrix3d;
using M4d = Eigen::Matrix4d;

struct EulerSolution {
  double A1{}; double A2{};
  double B1{}; double B2{};
  double C1{}; double C2{};
};

M4d trMatrix4x4(const V3d& delta);
M4d rotMatrix4x4(double angleDeg, char axis);

EulerSolution rot2euler(const M3d& R, bool isDeg = false);
M3d euler2rot(double A, double B, double C, bool isDeg = false);

V3d axisVec(char axis, double value);
V3d prjPointToLine(const V3d& l0, const V3d& v, const V3d& p);
V3d prjToPerpPlane(const V3d& vec, const V3d& n);

V3d poly(const V3d& p0, const V3d& p1, const V3d& p2);
V3d tanByPoly(const V3d& p, const V3d& coeffs);