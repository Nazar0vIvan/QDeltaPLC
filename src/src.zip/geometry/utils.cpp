#include "utils.h"

M4d trMatrix4x4(const V3d& delta)
{
  M4d T = M4d::Identity();
  T.block<3,1>(0,3) = delta;
  return T;
}

M4d rotMatrix4x4(double angleDeg, char axis)
{
  M4d R = M4d::Identity();
  const double ang = angleDeg * M_PI / 180.0;
  const double c = std::cos(ang), s = std::sin(ang);
  switch (axis) {
    case 'x': R(1,1)=c; R(1,2)=-s; R(2,1)= s; R(2,2)=c; break;
    case 'y': R(0,0)=c; R(0,2)= s; R(2,0)=-s; R(2,2)=c; break;
    case 'z': R(0,0)=c; R(0,1)=-s; R(1,0)= s; R(1,1)=c; break;
    }
  constexpr double EPS = 1e-4;
  R = R.unaryExpr([](double v){ return std::abs(v) <= EPS ? 0.0 : v; });
  return R;
}

V3d axisVec(char axis, double value)
{
  switch (axis) {
    case 'x': return { value, 0.0,   0.0 };
    case 'y': return { 0.0,   value, 0.0 };
    case 'z': return { 0.0,   0.0,   value };
    default:
      throw std::invalid_argument("axis must be one of: 'x','y','z'");
    }
}

V3d poly(const V3d& p0, const V3d& p1, const V3d& p2)
{
  M3d A;
  A << p0.x()*p0.x(), p0.x(), 1.0,
      p1.x()*p1.x(), p1.x(), 1.0,
      p2.x()*p2.x(), p2.x(), 1.0;

  return A.colPivHouseholderQr().solve(V3d(p0.y(), p1.y(), p2.y()));
}

EulerSolution rot2euler(const M3d &R, bool is_deg)
{
  const double B1 = -std::asin(R(2,0));
  const double B2 = M_PI + std::asin(R(2,0));

  const double cB1 = std::cos(B1);
  const double cB2 = std::cos(B2);

  const double C1 = std::atan2(R(2,1) / cB1, R(2,2) / cB1);
  const double C2 = std::atan2(R(2,1) / cB2, R(2,2) / cB2);

  const double A1 = std::atan2(R(1,0) / cB1, R(0,0) / cB1);
  const double A2 = std::atan2(R(1,0) / cB2, R(0,0) / cB2);

  const double k = is_deg ? (180.0 / M_PI) : 1.0;

  return { k*A1, k*A2, k*B1, k*B2, k*C1, k*C2 };
}

M3d euler2rot(double A, double B, double C, bool is_deg)
{
  const double k = is_deg ? (M_PI / 180.0) : 1.0;
  M3d R =
      (Eigen::AngleAxisd(A*k, V3d::UnitZ()) *
       Eigen::AngleAxisd(B*k, V3d::UnitY()) *
       Eigen::AngleAxisd(C*k, V3d::UnitX())).toRotationMatrix();
  double eps = 1e-4;
  R = R.unaryExpr([&](double v) { return std::abs(v) <= eps ? 0.0 : v; });
  return R;
}

V3d prjPointToLine(const V3d &l0, const V3d &v, const V3d &p)
{
  const double vv = v.squaredNorm();
  const double t = (p - l0).dot(v) / vv;
  return l0 + t * v;
}

V3d prjToPerpPlane(const V3d &vec, const V3d &n)
{
  V3d v = vec - vec.dot(n) * n;
  const double nn = v.norm();
  return v / nn;
}

V3d tanByPoly(const V3d &p, const V3d &coeffs)
{
  const double a0 = coeffs[0];
  const double a1 = coeffs[1];

  const double dy_dx = 2.0 * a0 * p.x() + a1;

  V3d t(1.0, dy_dx, 0.0);
  t.normalize();
  if (t.x() < 0.0) t = -t;
  return t;
}